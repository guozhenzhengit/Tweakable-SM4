#ifndef TNT_SM4_H__
#define TNT_SM4_H__

#include "types.h"

#define STATE_INBYTES 16
#define KEY_INBYTES 16
#define TWEAK_INBYTES 16

// macros
#define SM4_ENCRYPT 1
#define SM4_DECRYPT 0
#define SK_LENTH 38

#define SK_LENTH_1 39

#define TWEAK_L_1 27

/**
 * \brief          SM4 context structure
 */
typedef struct
{
    int mode;             /*!<  encrypt/decrypt   */
    unsigned long sk[32]; /*!<  SM4 subkeys       */
} sm4_context;
typedef struct
{
    int mode;                   /*!<  encrypt/decrypt   */
    unsigned long sk[SK_LENTH]; /*!<  SM4 subkeys       */
} TNT_sm4_context;

typedef struct
{
    int mode;                     /*!<  encrypt/decrypt   */
    unsigned long sk[SK_LENTH_1]; /*!<  SM4 subkeys       */
} TNT_sm4_context_1;

typedef struct
{                                /*!<  encrypt/decrypt   */
    unsigned long tk[TWEAK_L_1]; /*!<  SM4 subkeys       */
} Tweak_sm4_context_27;

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     * \brief          SM4 key schedule (128-bit, encryption)
     *
     * \param ctx      SM4 context to be initialized
     * \param key      16-byte secret key
     */
    void sm4_setkey_enc(sm4_context *ctx, unsigned char key[16]);
    void TNT_sm4_setkey_enc_6(TNT_sm4_context *ctx, unsigned char key[16], Tweak_sm4_context_27 *ctx_t);
    void TNT_sm4_setkey_enc_7(TNT_sm4_context_1 *ctx, unsigned char key[16], Tweak_sm4_context_27 *ctx_t);

    void TNT_sm4_settweak_enc_27(Tweak_sm4_context_27 *ctx, unsigned char tweak[16]);

    /**
     * \brief          SM4 key schedule (128-bit, decryption)
     *
     * \param ctx      SM4 context to be initialized
     * \param key      16-byte secret key
     */
    void sm4_setkey_dec(sm4_context *ctx, unsigned char key[16]);

    /**
     * \brief          SM4-ECB block encryption/decryption
     * \param ctx      SM4 context
     * \param mode     SM4_ENCRYPT or SM4_DECRYPT
     * \param length   length of the input data
     * \param input    input block
     * \param output   output block
     */
    void TNT_sm4_crypt_ecb(TNT_sm4_context *ctx,
                           int mode,
                           int length,
                           unsigned char *input,
                           unsigned char *output);

    void TNT_sm4_crypt_ecb_7(TNT_sm4_context_1 *ctx,
                             int mode,
                             int length,
                             unsigned char *input,
                             unsigned char *output);

    void sm4_crypt_ecb(sm4_context *ctx,
                       int mode,
                       int length,
                       unsigned char *input,
                       unsigned char *output);

    /**
     * \brief          SM4-CBC buffer encryption/decryption
     * \param ctx      SM4 context
     * \param mode     SM4_ENCRYPT or SM4_DECRYPT
     * \param length   length of the input data
     * \param iv       initialization vector (updated after use)
     * \param input    buffer holding the input data
     * \param output   buffer holding the output data
     */
    void sm4_crypt_cbc(sm4_context *ctx,
                       int mode,
                       int length,
                       unsigned char iv[16],
                       unsigned char *input,
                       unsigned char *output);

    void TNT_SM4_Retweak_ENC(
        uint8_t *cipher,
        uint8_t *plain,
        uint8_t *key,
        uint8_t *tweak,
        size_t mlen);
    void SM4_Retweak_ENC(
        uint8_t *cipher,
        uint8_t *plain,
        uint8_t *key,
        size_t mlen);

    void TNT_SM4_Retweak_ENC_7(
        uint8_t *cipher,
        uint8_t *plain,
        uint8_t *key,
        uint8_t *tweak,
        size_t mlen);

#ifdef __cplusplus
}
#endif

#endif