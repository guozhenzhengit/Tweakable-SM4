#include <algorithm>
#include <iostream>
#include <vector>

using namespace std;
static const unsigned char pi[10] = {0x03, 0x01, 0x04, 0x1, 0x05, 0x09, 0x02, 0x06, 0x05, 0x03};
static const unsigned char Position_6[6][2] = {
    {0x03, 0x05},
    {0x06, 0x0a},
    {0x0b, 0x0f},
    {0x10, 0x13},
    {0x14, 0x18},
    {0x19, 0x1b}};
void randperm(int Num)
{
    vector<int> temp;
    for (int i = 0; i < Num; ++i)
    {
        temp.push_back(i);
    }

    random_shuffle(temp.begin(), temp.end());

    for (int i = 0; i < temp.size(); i++)
    {
        cout << temp[i] << " ";
    }
    cout << endl;
    vector<int> pii;
    for (int i = 0; i < 6; ++i)
    {
        pii.push_back(pi[temp[i]]);
    }
    for (int i = 0; i < pii.size(); i++)
    {
        cout << pii[i] << " ";
    }
    cout << endl;
    vector<int> range;
    for (int i = 0; i < 6; ++i)
    {
        range.push_back(Position_6[i][1] - Position_6[i][0]);
    }
    for (int i = 0; i < range.size(); i++)
    {
        cout << range[i] << " ";
    }
    cout << endl;
    vector<int> positions;
    for (int i = 0; i < 6; ++i)
    {
        positions.push_back(pii[i] % range[i] + Position_6[i][0]);
    }
    for (int i = 0; i < positions.size(); i++)
    {
        cout << positions[i] << " ";
    }
}
int main()
{
    randperm(10);
    return 0;
}