#include <string.h>
#include <stdio.h>
#include "TNT_SM4.h"
using namespace std;
int test()
{
    unsigned char key[16] = {0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef, 0xfe, 0xdc, 0xba, 0x98, 0x76, 0x54, 0x32, 0x10};
    unsigned char input[16] = {0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef, 0xfe, 0xdc, 0xba, 0x98, 0x76, 0x54, 0x32, 0x10};
    unsigned char tweak[16] = {0x01,
                               0x23,
                               0x45,
                               0x67,
                               0x89,
                               0xab,
                               0xcd,
                               0xef,
                               0xfe,
                               0xdc,
                               0xba,
                               0x98,
                               0x76,
                               0x54,
                               0x32,
                               0x10};
    unsigned char output[16];
    unsigned char output1[16];
    sm4_context ctx;
    TNT_sm4_context ctxx;
    unsigned long i;

    // encrypt standard testing vector
    // cout << "ok5" << endl;
    sm4_setkey_enc(&ctx, key);
    TNT_sm4_setkey_enc(&ctxx, key);
    // cout << "ok4" << endl;
    sm4_crypt_ecb(&ctx, 1, 16, input, output);
    TNT_sm4_crypt_ecb(&ctxx, 1, 16, input, output1, tweak);
    for (i = 0; i < 16; i++)
        printf("%02x ", output[i]);
    printf("\n");
    for (i = 0; i < 16; i++)
        printf("%02x ", output1[i]);
    printf("\n");

    // // decrypt testing
    // sm4_setkey_dec(&ctx, key);
    // sm4_crypt_ecb(&ctx, 0, 16, output, output);
    // for (i = 0; i < 16; i++)
    //     printf("%02x ", output[i]);
    // printf("\n");

    // // decrypt 1M times testing vector based on standards.
    // i = 0;
    // sm4_setkey_enc(&ctx, key);
    // while (i < 1000000)
    // {
    //     sm4_crypt_ecb(&ctx, 1, 16, input, input);
    //     i++;
    // }
    // for (i = 0; i < 16; i++)
    //     printf("%02x ", input[i]);
    // printf("\n");

    return 0;
}