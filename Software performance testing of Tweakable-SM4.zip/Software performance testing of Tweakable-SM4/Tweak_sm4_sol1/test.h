#ifndef TEST_H__
#define TEST_H__

#include "TNT_SM4.h"

void test();

#endif