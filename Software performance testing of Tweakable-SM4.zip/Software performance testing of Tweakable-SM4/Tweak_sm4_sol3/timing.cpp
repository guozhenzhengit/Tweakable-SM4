/** @file timing.cpp
 */
#ifdef __GNUC__
#include <sched.h>
#include <unistd.h>
#endif

#include "timing.h"

using namespace std;

#ifdef _MSC_VER
#define DUAL_CORE

#if defined(DUAL_CORE)
#define WINDOWS_LEAN_AND_MEAN
#include <windows.h>
#endif
#include <string.h>
#include <math.h>

#include <intrin.h>
#pragma intrinsic(__rdtsc)

__inline unsigned long long read_tsc(void)
{
    return __rdtsc();
}

#if defined(_M_IX86)
#if _M_IX86 == 500
#define PROCESSOR "Pentium"
#elif _M_IX86 == 600
#define PROCESSOR "P2/P3/P4"
#else
#define PROCESSOR ""
#endif
#elif defined(_M_X64)
#define PROCESSOR "AMD64/EMT64"
#else
#define PROCESSOR ""
#endif

#if defined(_WIN64)

#define CurrentProcessorNumber GetCurrentProcessorNumber

#else

unsigned long CurrentProcessorNumber(void)
{
    __asm
    {
        mov     eax,1
        cpuid
        shr     ebx,24
        mov     eax, ebx
    }
}

#endif

void setCPUaffinity()
{
#if defined(DUAL_CORE) && defined(_WIN32)
    HANDLE ph;
    DWORD_PTR afp;
    DWORD_PTR afs;
    ph = GetCurrentProcess();
    if (GetProcessAffinityMask(ph, &afp, &afs))
    {
        afp &= (1 << CurrentProcessorNumber());
        if (!SetProcessAffinityMask(ph, afp))
        {
            printf("Couldn't set Process Affinity Mask\n\n");
        }
    }
    else
    {
        printf("Couldn't get Process Affinity Mask\n\n");
    }
#endif
}

#else
#ifdef __GNUC__
#include <sys/resource.h>
#include <x86intrin.h>
inline unsigned long long read_tsc(void)
{
#if defined(__i386__)
    unsigned long long cycles;
    __asm__ volatile(".byte 0x0f, 0x31"
                     : "=A"(cycles));
    return cycles;
#else
#if defined(__x86_64__)
    unsigned int hi, lo;
    __asm__ volatile("rdtsc"
                     : "=a"(lo), "=d"(hi));
    return (((unsigned long long)lo) | ((unsigned long long)(hi) << 32));
#else
#error "Unsupported architecture for counting cycles"
#endif
#endif
}

void setCPUaffinity()
{
    cpu_set_t cpu_mask;
    CPU_SET(0x1, &cpu_mask);
    if (sched_setaffinity(getpid(), sizeof(cpu_mask), &cpu_mask) == -1)
    {
        printf("Impossible to set CPU affinity...\n");
    }
}
#endif
#endif

#define RAND(a, b) (((a = 36969 * (a & 65535) + (a >> 16)) << 16) + \
                    (b = 18000 * (b & 65535) + (b >> 16)))

void block_rndfill(unsigned char *buf, const int len)
{
    static unsigned long a[2], mt = 1, count = 4;
    static unsigned char r[4];
    int i;

    if (mt)
    {
        mt = 0;
        *(unsigned long long *)a = read_tsc();
    }

    for (i = 0; i < len; ++i)
    {
        if (count == 4)
        {
            *(unsigned long *)r = RAND(a[0], a[1]);
            count = 0;
        }

        buf[i] = r[count++];
    }
}

#define MAX_MESSAGE_LENGTH (1UL << 13UL)
#define SAMPLE1 1000
#define SAMPLE2 10000

/** 处理短消息所需的最小时钟周期的测量时，循环的次数 */
const int loops = 100;

/** 处理长消息所需的最小时钟周期的测量时，循环的次数 */
const int loops_longMessage = 2;

#define TRUE 1
#define FALSE 0

int timeBase(double *av, double *sig)
{
    volatile int i, tol, lcnt, sam_cnt;
    volatile double cy, av1, sig1;

    tol = 10;
    lcnt = sam_cnt = 0;
    while (!sam_cnt)
    {
        av1 = sig1 = 0.0;

        for (i = 0; i < SAMPLE1; ++i)
        {
            cy = (volatile double)read_tsc();
            cy = (volatile double)read_tsc() - cy;

            av1 += cy;
            sig1 += cy * cy;
        }

        av1 /= SAMPLE1;
        sig1 = sqrt((sig1 - av1 * av1 * SAMPLE1) / SAMPLE1);
        sig1 = (sig1 < 0.05 * av1 ? 0.05 * av1 : sig1);

        *av = *sig = 0.0;
        for (i = 0; i < SAMPLE2; ++i)
        {
            cy = (volatile double)read_tsc();
            cy = (volatile double)read_tsc() - cy;

            if (cy > av1 - sig1 && cy < av1 + sig1)
            {
                *av += cy;
                *sig += cy * cy;
                sam_cnt++;
            }
        }

        if (10 * sam_cnt > 9 * SAMPLE2)
        {
            *av /= sam_cnt;
            *sig = sqrt((*sig - *av * *av * sam_cnt) / sam_cnt);

            if (*sig > (tol / 100.0) * *av)
                sam_cnt = 0;
        }
        else
        {
            if (lcnt++ == 10)
            {
                lcnt = 0;
                tol += 5;
                if (tol > 30)
                    return FALSE;
            }
            sam_cnt = 0;
        }
    }
    return TRUE;
}

// int time_key8(double *av, double *sig, unsigned int k_len)
// {
//     volatile int i, tol, lcnt, sam_cnt;
//     volatile double cy, av1, sig1;
//     unsigned char userKey[8][16];
//     unsigned char subkey[EXTENDED_KEY_BYTE_NUMBER];

//     block_rndfill(userKey[0], 8 * 16);

//     tol = 10;
//     lcnt = sam_cnt = 0;
//     while (!sam_cnt)
//     {
//         av1 = sig1 = 0.0;

//         /** 执行初始采样1，得到采样1均值和采样1标准差 */
//         for (i = 0; i < SAMPLE1; ++i)
//         {
//             cy = (double)read_tsc();
//             Key_Schedule(userKey[0], k_len, 0, subkey);
//             Key_Schedule(userKey[1], k_len, 0, subkey);
//             Key_Schedule(userKey[2], k_len, 0, subkey);
//             Key_Schedule(userKey[3], k_len, 0, subkey);
//             Key_Schedule(userKey[4], k_len, 0, subkey);
//             Key_Schedule(userKey[5], k_len, 0, subkey);
//             Key_Schedule(userKey[6], k_len, 0, subkey);
//             Key_Schedule(userKey[7], k_len, 0, subkey);
//             cy = (double)read_tsc() - cy;

//             av1 += cy;
//             sig1 += cy * cy;
//         }

//         av1 /= SAMPLE1;
//         sig1 = sqrt((sig1 - av1 * av1 * SAMPLE1) / SAMPLE1);
//         sig1 = (sig1 < 0.05 * av1 ? 0.05 * av1 : sig1);

//         /** 执行正式采样2，得到正式采样2均值和采样2标准差 */
//         *av = *sig = 0.0;
//         for (i = 0; i < SAMPLE2; ++i)
//         {
//             cy = (double)read_tsc();
//             Key_Schedule(userKey[0], k_len, 0, subkey);
//             Key_Schedule(userKey[1], k_len, 0, subkey);
//             Key_Schedule(userKey[2], k_len, 0, subkey);
//             Key_Schedule(userKey[3], k_len, 0, subkey);
//             Key_Schedule(userKey[4], k_len, 0, subkey);
//             Key_Schedule(userKey[5], k_len, 0, subkey);
//             Key_Schedule(userKey[6], k_len, 0, subkey);
//             Key_Schedule(userKey[7], k_len, 0, subkey);
//             cy = (double)read_tsc() - cy;

//             /** 采样2中，一次采样的时间只有在采样1均值+/-采样1标准差范围内，才记为一次有效采样 */
//             if (cy > av1 - sig1 && cy < av1 + sig1)
//             {
//                 *av += cy;
//                 *sig += cy * cy;
//                 sam_cnt++;
//             }
//         }

//         /** 要求采样2有效采样次数占总采样次数的比例达到 90% 以上 **/
//         if (10 * sam_cnt > 9 * SAMPLE2)
//         {
//             *av /= sam_cnt;
//             *sig = sqrt((*sig - *av * *av * sam_cnt) / sam_cnt);
//             /** 并且标准差要求小于均值的 10% -> 15% -> 20% -> 30% */
//             if (*sig > (tol / 100.0) * *av)
//                 sam_cnt = 0;
//         }
//         else
//         {
//             /** 若连续测试10次都没有成功则将标准差的可接受限度放低 5%，再次重新采样测量 */
//             if (lcnt++ == 10)
//             {
//                 lcnt = 0;
//                 tol += 5;
//                 /** 直到标准差的可接受限度降到了均值的 30% 时，仍没有测试成功。此时返回FALSE，测试失败。*/
//                 if (tol > 30)
//                     return FALSE;
//             }
//             sam_cnt = 0;
//         }
//     }

//     /** 测试成功，返回 TURE */
//     return TRUE;
// }

int time_SM4_Rekey_ENC_enc16(double *av, double *sig, unsigned long long dataLengthInBytes)
{
    volatile int i, tol, lcnt, sam_cnt;
    volatile double cy, av1, sig1;
    unsigned char pt[4][MAX_MESSAGE_LENGTH];
    unsigned char key[4][MAX_MESSAGE_LENGTH];
    // cout << "ok2" << endl;
    for (int i = 0; i < 4; i++)
    {
        block_rndfill(pt[i], dataLengthInBytes);
        block_rndfill(key[i], dataLengthInBytes);
    }

    tol = 10;
    lcnt = sam_cnt = 0;
    while (!sam_cnt)
    {
        av1 = sig1 = 0.0;

        /** 执行初始采样1，得到采样1均值和采样1标准差 */
        for (i = 0; i < SAMPLE1; ++i)
        {

            cy = (double)read_tsc();
            SM4_Retweak_ENC(pt[0], pt[0], key[0], dataLengthInBytes);
            SM4_Retweak_ENC(pt[1], pt[1], key[1], dataLengthInBytes);
            SM4_Retweak_ENC(pt[2], pt[2], key[2], dataLengthInBytes);
            SM4_Retweak_ENC(pt[3], pt[3], key[3], dataLengthInBytes);
            SM4_Retweak_ENC(pt[0], pt[0], key[0], dataLengthInBytes);
            SM4_Retweak_ENC(pt[1], pt[1], key[1], dataLengthInBytes);
            SM4_Retweak_ENC(pt[2], pt[2], key[2], dataLengthInBytes);
            SM4_Retweak_ENC(pt[3], pt[3], key[3], dataLengthInBytes);
            SM4_Retweak_ENC(pt[0], pt[0], key[0], dataLengthInBytes);
            SM4_Retweak_ENC(pt[1], pt[1], key[1], dataLengthInBytes);
            SM4_Retweak_ENC(pt[2], pt[2], key[2], dataLengthInBytes);
            SM4_Retweak_ENC(pt[3], pt[3], key[3], dataLengthInBytes);
            SM4_Retweak_ENC(pt[0], pt[0], key[0], dataLengthInBytes);
            SM4_Retweak_ENC(pt[1], pt[1], key[1], dataLengthInBytes);
            SM4_Retweak_ENC(pt[2], pt[2], key[2], dataLengthInBytes);
            SM4_Retweak_ENC(pt[3], pt[3], key[3], dataLengthInBytes);
            cy = (double)read_tsc() - cy;

            av1 += cy;
            sig1 += cy * cy;
        }

        av1 /= SAMPLE1;
        sig1 = sqrt((sig1 - av1 * av1 * SAMPLE1) / SAMPLE1);
        sig1 = (sig1 < 0.05 * av1 ? 0.05 * av1 : sig1);

        /** 执行正式采样2，得到正式采样2均值和采样2标准差 */
        *av = *sig = 0.0;
        for (i = 0; i < SAMPLE2; ++i)
        {
            cy = (double)read_tsc();
            SM4_Retweak_ENC(pt[0], pt[0], key[0], dataLengthInBytes);
            SM4_Retweak_ENC(pt[1], pt[1], key[1], dataLengthInBytes);
            SM4_Retweak_ENC(pt[2], pt[2], key[2], dataLengthInBytes);
            SM4_Retweak_ENC(pt[3], pt[3], key[3], dataLengthInBytes);
            SM4_Retweak_ENC(pt[0], pt[0], key[0], dataLengthInBytes);
            SM4_Retweak_ENC(pt[1], pt[1], key[1], dataLengthInBytes);
            SM4_Retweak_ENC(pt[2], pt[2], key[2], dataLengthInBytes);
            SM4_Retweak_ENC(pt[3], pt[3], key[3], dataLengthInBytes);
            SM4_Retweak_ENC(pt[0], pt[0], key[0], dataLengthInBytes);
            SM4_Retweak_ENC(pt[1], pt[1], key[1], dataLengthInBytes);
            SM4_Retweak_ENC(pt[2], pt[2], key[2], dataLengthInBytes);
            SM4_Retweak_ENC(pt[3], pt[3], key[3], dataLengthInBytes);
            SM4_Retweak_ENC(pt[0], pt[0], key[0], dataLengthInBytes);
            SM4_Retweak_ENC(pt[1], pt[1], key[1], dataLengthInBytes);
            SM4_Retweak_ENC(pt[2], pt[2], key[2], dataLengthInBytes);
            SM4_Retweak_ENC(pt[3], pt[3], key[3], dataLengthInBytes);
            cy = (double)read_tsc() - cy;

            /** 采样2中，一次采样的时间只有在采样1均值+/-采样1标准差范围内，才记为一次有效采样 */
            if (cy > av1 - sig1 && cy < av1 + sig1)
            {
                *av += cy;
                *sig += cy * cy;
                sam_cnt++;
            }
        }

        /** 要求采样2有效采样次数占总采样次数的比例达到 90% 以上 **/
        if (10 * sam_cnt > 9 * SAMPLE2)
        {
            *av /= sam_cnt;
            *sig = sqrt((*sig - *av * *av * sam_cnt) / sam_cnt);
            /** 并且标准差要求小于均值的 10% -> 15% -> 20% -> 30% */
            if (*sig > (tol / 100.0) * *av)
                sam_cnt = 0;
        }
        else
        {
            /** 若连续测试10次都没有成功则将标准差的可接受限度放低 5%，再次重新采样测量 */
            if (lcnt++ == 10)
            {
                lcnt = 0;
                /** 直到标准差的可接受限度降到了均值的 30% 时，仍没有测试成功。此时返回FALSE，测试失败。*/
                tol += 5;
                if (tol > 30)
                {
                    return FALSE;
                }
            }
            sam_cnt = 0;
        }
    }
    return TRUE;
}
int time_TNT_SM4_Retweak_ENC_enc16(double *av, double *sig, unsigned long long dataLengthInBytes)
{
    volatile int i, tol, lcnt, sam_cnt;
    volatile double cy, av1, sig1;
    unsigned char key[16];
    unsigned char pt[4][MAX_MESSAGE_LENGTH];
    unsigned char tweak[16];

    block_rndfill(key, 16);
    block_rndfill(tweak, 16);
    for (int i = 0; i < 4; i++)
    {
        block_rndfill(pt[i], dataLengthInBytes);
    }

    tol = 10;
    lcnt = sam_cnt = 0;
    while (!sam_cnt)
    {
        av1 = sig1 = 0.0;

        for (i = 0; i < SAMPLE1; ++i)
        {
            cy = (double)read_tsc();
            TNT_SM4_Retweak_ENC(pt[0], pt[0], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[1], pt[1], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[2], pt[2], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[3], pt[3], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[0], pt[0], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[1], pt[1], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[2], pt[2], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[3], pt[3], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[0], pt[0], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[1], pt[1], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[2], pt[2], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[3], pt[3], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[0], pt[0], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[1], pt[1], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[2], pt[2], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[3], pt[3], key, tweak, dataLengthInBytes);
            cy = (double)read_tsc() - cy;

            av1 += cy;
            sig1 += cy * cy;
        }

        av1 /= SAMPLE1;
        sig1 = sqrt((sig1 - av1 * av1 * SAMPLE1) / SAMPLE1);
        sig1 = (sig1 < 0.05 * av1 ? 0.05 * av1 : sig1);

        *av = *sig = 0.0;
        for (i = 0; i < SAMPLE2; ++i)
        {
            cy = (double)read_tsc();
            TNT_SM4_Retweak_ENC(pt[0], pt[0], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[1], pt[1], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[2], pt[2], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[3], pt[3], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[0], pt[0], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[1], pt[1], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[2], pt[2], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[3], pt[3], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[0], pt[0], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[1], pt[1], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[2], pt[2], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[3], pt[3], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[0], pt[0], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[1], pt[1], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[2], pt[2], key, tweak, dataLengthInBytes);
            TNT_SM4_Retweak_ENC(pt[3], pt[3], key, tweak, dataLengthInBytes);
            cy = (double)read_tsc() - cy;

            if (cy > av1 - sig1 && cy < av1 + sig1)
            {
                *av += cy;
                *sig += cy * cy;
                sam_cnt++;
            }
        }

        if (10 * sam_cnt > 9 * SAMPLE2)
        {
            *av /= sam_cnt;
            *sig = sqrt((*sig - *av * *av * sam_cnt) / sam_cnt);
            if (*sig > (tol / 100.0) * *av)
                sam_cnt = 0;
        }
        else
        {
            if (lcnt++ == 10)
            {
                lcnt = 0;
                tol += 5;
                if (tol > 30)
                {
                    return FALSE;
                }
            }
            sam_cnt = 0;
        }
    }
    return TRUE;
}

double enc_cycles(unsigned long long dataLengthInBytes)
{
    volatile double cy1, cy2, c1 = -1, c2 = -1;
    volatile int i;
    int out_len;
    unsigned char key[16];
    unsigned char *pt = new data_t[dataLengthInBytes];

    // 设置随机扩展密钥
    block_rndfill(key, 16);

    // 设置随机待处理数据
    block_rndfill(pt, dataLengthInBytes);
    c1 = c2 = 0xffffffffffffffff;

    // 执行一次加密，去除第一次执行的不稳定性
    SM4_Retweak_ENC(pt, pt, key, dataLengthInBytes);

    for (i = 0; i < loops; ++i)
    {
        block_rndfill(pt, dataLengthInBytes);

        // 测试 1 次 和 9 次的加密所需时钟周期数，相减得到 8 次的加密所需时钟周期数
        cy1 = (volatile double)read_tsc();
        SM4_Retweak_ENC(pt, pt, key, dataLengthInBytes);
        cy1 = (volatile double)read_tsc() - cy1;

        cy2 = (volatile double)read_tsc();
        SM4_Retweak_ENC(pt, pt, key, dataLengthInBytes);
        SM4_Retweak_ENC(pt, pt, key, dataLengthInBytes);
        SM4_Retweak_ENC(pt, pt, key, dataLengthInBytes);
        SM4_Retweak_ENC(pt, pt, key, dataLengthInBytes);
        SM4_Retweak_ENC(pt, pt, key, dataLengthInBytes);
        SM4_Retweak_ENC(pt, pt, key, dataLengthInBytes);
        SM4_Retweak_ENC(pt, pt, key, dataLengthInBytes);
        SM4_Retweak_ENC(pt, pt, key, dataLengthInBytes);
        SM4_Retweak_ENC(pt, pt, key, dataLengthInBytes);
        cy2 = (volatile double)read_tsc() - cy2;

        /** 当循环了 10% 次之后，就比较稳定了 */
        if (i > (loops / 10))
        {
            /** 找到循环中的所需最小时钟周期数 */
            c1 = (c1 < cy1 ? c1 : cy1);
            c2 = (c2 < cy2 ? c2 : cy2);
        }
    }
    delete[] pt;
    /** 返回 1 次加密算法加密指定长度消息所需最小时钟周期数*/
    return ((c2 - c1) + 4.0) / 8.0;
}
double TNT_enc_cycles_128(unsigned long long dataLengthInBytes)
{
    volatile double cy1, cy2, c1 = -1, c2 = -1;
    volatile int i;
    int out_len;
    unsigned char key[16];
    unsigned char *pt = new data_t[dataLengthInBytes];
    unsigned char tweak[16];
    // 设置随机扩展密钥
    block_rndfill(key, 16);
    block_rndfill(tweak, 16);

    // 设置随机待处理数据
    block_rndfill(pt, dataLengthInBytes);
    c1 = c2 = 0xffffffffffffffff;

    // 执行一次加密，去除第一次执行的不稳定性
    TNT_SM4_Retweak_ENC(pt, pt, key, tweak, dataLengthInBytes);

    for (i = 0; i < loops; ++i)
    {
        block_rndfill(pt, dataLengthInBytes);

        // 测试 1 次 和 9 次的加密所需时钟周期数，相减得到 8 次的加密所需时钟周期数
        cy1 = (volatile double)read_tsc();
        TNT_SM4_Retweak_ENC(pt, pt, key, tweak, dataLengthInBytes);
        cy1 = (volatile double)read_tsc() - cy1;

        cy2 = (volatile double)read_tsc();
        TNT_SM4_Retweak_ENC(pt, pt, key, tweak, dataLengthInBytes);
        TNT_SM4_Retweak_ENC(pt, pt, key, tweak, dataLengthInBytes);
        TNT_SM4_Retweak_ENC(pt, pt, key, tweak, dataLengthInBytes);
        TNT_SM4_Retweak_ENC(pt, pt, key, tweak, dataLengthInBytes);
        TNT_SM4_Retweak_ENC(pt, pt, key, tweak, dataLengthInBytes);
        TNT_SM4_Retweak_ENC(pt, pt, key, tweak, dataLengthInBytes);
        TNT_SM4_Retweak_ENC(pt, pt, key, tweak, dataLengthInBytes);
        TNT_SM4_Retweak_ENC(pt, pt, key, tweak, dataLengthInBytes);
        TNT_SM4_Retweak_ENC(pt, pt, key, tweak, dataLengthInBytes);
        cy2 = (volatile double)read_tsc() - cy2;

        /** 当循环了 10% 次之后，就比较稳定了 */
        if (i > (loops / 10))
        {
            /** 找到循环中的所需最小时钟周期数 */
            c1 = (c1 < cy1 ? c1 : cy1);
            c2 = (c2 < cy2 ? c2 : cy2);
        }
    }
    delete[] pt;
    /** 返回 1 次加密算法加密指定长度消息所需最小时钟周期数*/
    return ((c2 - c1) + 4.0) / 8.0;
}

static unsigned long kl[1] = {128};

static unsigned long ml[] = {
    // 1UL << 2UL,
    // 1UL << 3UL,
    // 1UL << 4UL,
    // 1UL << 5UL,
    // 1UL << 6UL,
    // 1UL << 7UL,
    // 1UL << 8UL
    1UL << 7UL,
    1UL << 8UL,
    1UL << 9UL,
    1UL << 10UL,
    1UL << 11UL,
    1UL << 12UL,
    1UL << 13UL};
static unsigned long al[] = {
    1UL << 7UL,
    1UL << 8UL,
    1UL << 9UL,
    1UL << 10UL,
    1UL << 11UL,
    1UL << 12UL,
    1UL << 13UL};

static double et, et_128, et_32;

void timing()
{
    ofstream fout;
    string fn = "TNT_SM4_ENC_Timing.csv";
    double a0, av, sig;
    int i, w;
    unsigned long long di;

    setCPUaffinity();

    fout.open(fn.c_str(), ios::app);
    fout.setf(ios::fixed);

    fout << "SM4 Encryption Average Timing" << endl;
    fout << setw(30) << "P_len(bytes)" << setw(30) << "SM4_REKEY(cycles/byte)" << setw(30) << "TNT_RETWEAK(cycles/byte)" << endl;
    while (timeBase(&a0, &sig) != TRUE)
    {
    }
    fout.setf(ios::fixed);
    for (di = 0; di < sizeof(ml) / sizeof(ml[0]); di++)
    {
        fout << setw(30) << ml[di];

        while (time_SM4_Rekey_ENC_enc16(&av, &sig, ml[di]) != TRUE)
        {
        }
        sig *= 100.0 / av;
        av = (int)(10.0 * (av - a0) / (16.0 * (ml[di]))) / 10.0;
        sig = (int)(10 * sig) / 10.0;
        fout << setw(20) << setprecision(2) << av << " (" << setw(6) << sig << "%)";

        while (time_TNT_SM4_Retweak_ENC_enc16(&av, &sig, ml[di]) != TRUE)
        {
        }
        sig *= 100.0 / av;
        av = (int)(10.0 * (av - a0) / (16.0 * (ml[di]))) / 10.0;
        sig = (int)(10 * sig) / 10.0;
        fout << setw(20) << setprecision(2) << av << " (" << setw(6) << sig << "%)";

        fout << endl;
    }
    fout << "SM4 128128 Encryption/Decryption Minimal Timing" << endl;
    fout << setw(30) << "P_len(bytes)" << setw(30) << "ENC(cycles/byte)" << setw(30) << "TNT_128(cycles/byte)" << endl;

    /** 测试加解密短消息最小速率(cycles/byte) */
    for (di = 0; di < 5; di++)
    {
        fout << setw(30) << ml[di];

        et = enc_cycles(ml[di]);
        // dt = dec_cycles(128, ml[di]);

        av = et / (ml[di]);
        w = (int)(10.0 * av + 0.5);
        fout << setw(20) << w / 10 << "." << setw(1) << w % 10 << setw(6);

        et_128 = TNT_enc_cycles_128(ml[di]);
        av = et_128 / (ml[di]);
        w = (int)(10.0 * av + 0.5);
        fout << setw(20) << w / 10 << "." << setw(1) << w % 10 << setw(6);
        fout << endl;
    }
    fout << endl;

    fout.unsetf(ios::fixed);
    fout.close();
}
